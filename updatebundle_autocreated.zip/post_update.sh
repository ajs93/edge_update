#!/bin/sh
#
# Post-update script
#
# This script will be executed after completing all the file renaming
# corresponding to the last update
#

printf "Post-update script started.\n"

# Real work here

printf "Post-update script finished.\n"

exit 0